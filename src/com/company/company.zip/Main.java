package com.company;

import java.util.Scanner;
import java.io.*;
import java.util.*;
import java.util.stream.Collectors;

public class Main {
    public static List<Gwiazda> ListaGwiazd = new ArrayList<>();

    public static void clearScreen() {
        System.out.print("\033[H\033[2J");
        System.out.flush();
    }

    public static void AddStar() {
        Gwiazda test = new Gwiazda();
        clearScreen(); // nie działa?
        test.SetNazwa();
        test.SetDeklinacja();
        test.SetRektascencja();
        test.SetObserwowalnaW();
        test.SetOdleglosc();
        test.SetGwiazdozbior();
        test.SetPolkula();
        test.SetTemperatura();
        test.SetMasa();
        Gwiazda.NadajKatalog(test, LiczGwiazdozbiory(test.Gwiazdozbior));
        ListaGwiazd.add(test);
    }


    public static int LiczGwiazdozbiory(String nazwaGw) {
        List<Gwiazda> matches = ListaGwiazd.stream()
                .filter(h -> h.Gwiazdozbior.equals(nazwaGw))
                .toList();
        return matches.size();
    }

    public static void PrintFilter(List<Gwiazda> lista) {
        System.out.printf("%20s %10s %20s %30s %30s %30s %20s %20s %20s %20s", "NAZWA KATALOGOWA", "NAZWA", "DEKLINACJA", "REKTASCENCJA", "OBSERWOWALNA WIELKOŚĆ", "ABSOLUTNA WIELKOŚĆ", "ODLEGŁOŚĆ", "PÓŁKULA", "TEMPERATURA", "MASA" + '\n');
        for (Gwiazda x : lista) {
            x.FullInfo();
            System.out.println();
        }
    }

    public static void PrintStars() {
        System.out.println("--- lista gwiazd ---");
        String Gw = "";
        Collections.sort(ListaGwiazd, (o1, o2) -> (o1.KatalogNazwa.compareTo(o2.KatalogNazwa)));
        Collections.sort(ListaGwiazd, (o1, o2) -> (o1.Gwiazdozbior.compareTo(o2.Gwiazdozbior)));
        int i = 1;
        for (Gwiazda x : ListaGwiazd) {

            if (Gw.compareTo(x.Gwiazdozbior) != 0) {
                System.out.println("Gwiazdozbiór " + x.Gwiazdozbior);
                i = 1;
            }
            Gwiazda.NadajKatalog(x, i - 1);
            System.out.print("  " + i + ". " + x + "\n");
            //   x.FullInfo();
            Gw = x.Gwiazdozbior;
            i++;
        }
        System.out.println("---------------------");
    }

    public static void SaveStars() {
        ObjectOutputStream strumien;
        try {
            strumien = new ObjectOutputStream(new FileOutputStream("Gwiazdy"));
            for (Gwiazda gwiazda : ListaGwiazd) {
                //  X=ListaGwiazd.get(i);
                strumien.writeObject(gwiazda);
            }
        } catch (Exception e) {

            e.printStackTrace();
        }
    }

    public static void Czytaj() {
        ObjectInputStream strumien;
        try {
            strumien = new ObjectInputStream(new FileInputStream("Gwiazdy"));
            Object obj;
            while ((obj = strumien.readObject())!=null) {
                if (obj instanceof Gwiazda) {
                    ListaGwiazd.add((Gwiazda) obj);
                }
            }
        } catch (EOFException ex) {
            // nic
        } catch (Exception e) {
            System.out.println("-- brak pliku wejściowego --");
        }
    }

    public static void usun(String NazwaKatalogowa) {
        Object DoUsuniecia = null;
        for (Gwiazda x : ListaGwiazd) {
            if (NazwaKatalogowa.compareTo(x.KatalogNazwa) == 0) {
                DoUsuniecia = x;
                break;
            }
        }
        if (DoUsuniecia != null)
            ListaGwiazd.remove(DoUsuniecia);
        PrintStars();
    }

    public static void main(String[] args) {
        Czytaj();
        System.out.println();
        while (true) {
            Scanner scanner = new Scanner(System.in);
            System.out.println("1. Lista");
            System.out.println("2. Wprowadź dane");
            System.out.println("3. Edytuj");
            System.out.println("4. Usuń");
            System.out.println("5. Lista z filtrem");
            System.out.println("6. Zapisz zmiany");
            int choice = scanner.nextInt();
            switch (choice) {
                case 1:
                    PrintStars();
                    break;
                case 2:
                    AddStar();
                    break;
                case 3:
                    System.out.print("Nazwa Katalogowa edytowanej gwiazdy: ");
                    scanner.nextLine();
                    Edytuj(scanner.nextLine());
                    break;
                case 4:
                    System.out.print("Nazwa Katalogowa usuwanej gwiazdy: ");
                    scanner.nextLine();
                    usun(scanner.nextLine());
                    break;
                case 5:
                    Filtruj();
                    break;
                case 6:
                    SaveStars();
                    break;
                default:
                    break;
            }
        }
    }

    public static void Edytuj(String NazwaKatalogowa) {
        Gwiazda DoEdycji = null;
        boolean exit = false;
        for (Gwiazda x : ListaGwiazd) {
            if (NazwaKatalogowa.compareTo(x.KatalogNazwa) == 0) {
                DoEdycji = x;
                break;
            }
        }
        if (DoEdycji != null) {
            while (!exit) {
                System.out.println("Edytuj: " + DoEdycji.KatalogNazwa);
                Scanner scanner = new Scanner(System.in);
                System.out.println(" 1. Nazwę");
                System.out.println(" 2. Deklinację");
                System.out.println(" 3. Rektascencję");
                System.out.println(" 4. Obserwowalną wielkośc");
                System.out.println(" 5. Absolutną wielkość");
                System.out.println(" 6. Odległość");
                System.out.println(" 7. Półkulę");
                System.out.println(" 8. Temperaturę");
                System.out.println(" 9. Masę");
                System.out.println("10. Zakończ edycję");
                int choice = scanner.nextInt();
                switch (choice) {
                    case 1:
                        DoEdycji.SetNazwa();
                        break;
                    case 2:
                        DoEdycji.SetDeklinacja();
                        break;
                    case 3:
                        DoEdycji.SetRektascencja();
                        break;
                    case 4:
                        DoEdycji.SetObserwowalnaW();
                        break;
                    case 5:
                        DoEdycji.SetAbsolutnaW();
                        break;
                    case 6:
                        DoEdycji.SetOdleglosc();
                        break;
                    case 7:
                        DoEdycji.SetPolkula();
                        break;
                    case 8:
                        DoEdycji.SetTemperatura();
                        break;
                    case 9:
                        DoEdycji.SetMasa();
                        break;
                    case 10:
                        exit = true;
                        break;
                    default:
                        break;
                }
            }
        } else
            System.out.println("nie znaleziono " + NazwaKatalogowa);
    }

    public static void Filtruj() {
        System.out.println("Wyświetl:");
        Scanner scanner = new Scanner(System.in);
        List<Gwiazda> ListaWynikow;
        System.out.println(" 1. Wszystkie gwiazdy w gwiazdozbiorze");
        System.out.println(" 2. Gwiazdy w podanej odległości");
        System.out.println(" 3. Gwiazdy z temperaturą z podanego przedziału");
        System.out.println(" 4. Gwiazdy o rozmiarach z podanego przedziału");
        System.out.println(" 5. Gwiazdy z pólkuli północnej / połudiowej");
        System.out.println(" 6. Potencjalne supernowe");
        int choice = scanner.nextInt();
        switch (choice) {
            case 1:
                System.out.println("Nazwa gwiazdozbioru: ");
                String Nazwa = scanner.next();
                ListaWynikow = ListaGwiazd.stream()
                        .filter(p -> p.Gwiazdozbior.compareTo(Nazwa) == 0)
                        .collect(Collectors.toList());
                PrintFilter(ListaWynikow);
                break;
            case 2:
                System.out.println("Minimalna odległość od gwiazdy: ");
                float minO = scanner.nextFloat();
                System.out.println("Maksymalna odległość od gwiazdy: ");
                float maxO = scanner.nextFloat();
                ListaWynikow = ListaGwiazd.stream()
                        .filter(p -> p.Odleglosc >= minO & p.Odleglosc <= maxO)
                        .collect(Collectors.toList());
                PrintFilter(ListaWynikow);
                break;
            case 3:
                System.out.println("Minimalna temperatura gwiazdy: ");
                float minT = scanner.nextFloat();
                System.out.println("Maksymalna temperatura gwiazdy: ");
                float maxT = scanner.nextFloat();
                ListaWynikow = ListaGwiazd.stream()
                        .filter(p -> p.Odleglosc >= minT & p.Odleglosc <= maxT)
                        .collect(Collectors.toList());
                PrintFilter(ListaWynikow);
                break;
            case 4:
                System.out.println("Minimalna wielkość gwiazdy: ");
                float minW = scanner.nextFloat();
                System.out.println("Maksymalna wielkość gwiazdy: ");
                float maxW = scanner.nextFloat();
                ListaWynikow = ListaGwiazd.stream()
                        .filter(p -> p.Odleglosc >= minW & p.Odleglosc <= maxW)
                        .collect(Collectors.toList());
                PrintFilter(ListaWynikow);
                break;
            case 5:
                System.out.println("Pólkula gwiazdy (true/false): ");
                ListaWynikow = ListaGwiazd.stream()
                        .filter(p -> p.Polkula)
                        .collect(Collectors.toList());
                PrintFilter(ListaWynikow);
                break;
            case 6:
                ListaWynikow = ListaGwiazd.stream()
                        .filter(p -> p.Masa >= 1.44)
                        .collect(Collectors.toList());
                PrintFilter(ListaWynikow);
                break;
            default:
                break;
        }
    }
}
